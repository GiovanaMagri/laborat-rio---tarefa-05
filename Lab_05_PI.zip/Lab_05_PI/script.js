/* ==========================================================
   Lab JS Eventos - Cadastro Inteligente
   Aulas 11 (JavaScript), 12 (DOM) e 13 (Eventos)
   ========================================================== */

// ----------------------------------------------------------
// 1. Seleção dos elementos do DOM
// ----------------------------------------------------------
const formCadastro = document.getElementById("formCadastro");

const nome = document.getElementById("nome");
const estado = document.getElementById("estado");
const cidade = document.getElementById("cidade");
const email = document.getElementById("email");
const senha = document.getElementById("senha");
const curso = document.getElementById("curso");
const termos = document.getElementById("termos");

const contadorNome = document.getElementById("contadorNome");
const mensagemNome = document.getElementById("mensagemNome");
const mensagemEmail = document.getElementById("mensagemEmail");
const mensagemSenha = document.getElementById("mensagemSenha");
const mensagemCurso = document.getElementById("mensagemCurso");
const mensagemTermos = document.getElementById("mensagemTermos");

const medidorSenha = document.getElementById("medidorSenha");
const forcaSenha = document.getElementById("forcaSenha");
const criterioTamanho = document.getElementById("criterioTamanho");
const criterioMaiuscula = document.getElementById("criterioMaiuscula");
const criterioMinuscula = document.getElementById("criterioMinuscula");
const criterioNumero = document.getElementById("criterioNumero");
const criterioEspecial = document.getElementById("criterioEspecial");

const resumoErros = document.getElementById("resumoErros");
const listaErros = document.getElementById("listaErros");
const btnEnviar = document.getElementById("btnEnviar");
const dicaBotao = document.getElementById("dicaBotao");
const mensagemSucesso = document.getElementById("mensagemSucesso");

// ----------------------------------------------------------
// 2. Dados
// ----------------------------------------------------------
const LIMITE_NOME = 50;
const TEXTO_DICA = dicaBotao.textContent;

const cidadesPorUF = {
  SP: ["Campinas", "São Paulo", "Santos"],
  RJ: ["Rio de Janeiro", "Niterói", "Petrópolis"],
  MG: ["Belo Horizonte", "Uberlândia", "Ouro Preto"],
  PR: ["Curitiba", "Londrina", "Maringá"]
};

// E-mail: texto + @ + texto + ponto + texto (ex.: nome@dominio.com)
const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ----------------------------------------------------------
// 3. Funções de validação (só retornam true ou false)
// ----------------------------------------------------------
function nomeValido() {
  return nome.value.trim().length >= 3;
}

function emailValido() {
  return regexEmail.test(email.value.trim());
}

/*
  Força da senha. São 5 critérios:
  8+ caracteres, maiúscula, minúscula, número e caractere especial.
  - Fraca: menos de 8 caracteres OU apenas 2 critérios (ou menos)
  - Média: 8+ caracteres e 3 ou 4 critérios
  - Forte: os 5 critérios
  Retorna: 0 = vazia, 1 = fraca, 2 = média, 3 = forte
*/
function calcularForca() {
  const texto = senha.value;

  if (texto.length === 0) {
    return 0;
  }

  let pontos = 0;
  if (texto.length >= 8) pontos++;
  if (/[A-Z]/.test(texto)) pontos++;
  if (/[a-z]/.test(texto)) pontos++;
  if (/[0-9]/.test(texto)) pontos++;
  if (/[^A-Za-z0-9]/.test(texto)) pontos++;

  if (texto.length < 8 || pontos <= 2) {
    return 1;
  } else if (pontos <= 4) {
    return 2;
  } else {
    return 3;
  }
}

function senhaValida() {
  return calcularForca() >= 2;   // pelo menos Média
}

function cursoValido() {
  return curso.value !== "";
}

function termosValidos() {
  return termos.checked;
}

// ----------------------------------------------------------
// 4. Funções de interface (classes, ARIA e mensagens)
// ----------------------------------------------------------
function mostrarEstado(campo, mensagem, ok, textoOk, textoErro) {
  if (ok) {
    campo.classList.add("ok");
    campo.classList.remove("erro");
    campo.setAttribute("aria-invalid", "false");
    mensagem.classList.add("mensagem-ok");
    mensagem.classList.remove("mensagem-erro");
    mensagem.textContent = textoOk;
  } else {
    campo.classList.add("erro");
    campo.classList.remove("ok");
    campo.setAttribute("aria-invalid", "true");
    mensagem.classList.add("mensagem-erro");
    mensagem.classList.remove("mensagem-ok");
    mensagem.textContent = textoErro;
  }
}

function limparEstado(campo, mensagem) {
  campo.classList.remove("ok");
  campo.classList.remove("erro");
  campo.setAttribute("aria-invalid", "false");
  mensagem.classList.remove("mensagem-ok");
  mensagem.classList.remove("mensagem-erro");
  mensagem.textContent = "";
}

// Marca um critério da lista como atendido ou pendente
function marcarCriterio(item, atendido) {
  if (atendido) {
    item.classList.add("atendido");
  } else {
    item.classList.remove("atendido");
  }
}

function mostrarForca() {
  const forca = calcularForca();
  const texto = senha.value;

  medidorSenha.classList.remove("forca-fraca", "forca-media", "forca-forte");
  forcaSenha.classList.remove("forca-fraca", "forca-media", "forca-forte");

  if (forca === 0) {
    forcaSenha.textContent = "Força da senha: não informada";
  } else if (forca === 1) {
    medidorSenha.classList.add("forca-fraca");
    forcaSenha.classList.add("forca-fraca");
    forcaSenha.textContent = "Força da senha: Fraca";
  } else if (forca === 2) {
    medidorSenha.classList.add("forca-media");
    forcaSenha.classList.add("forca-media");
    forcaSenha.textContent = "Força da senha: Média";
  } else {
    medidorSenha.classList.add("forca-forte");
    forcaSenha.classList.add("forca-forte");
    forcaSenha.textContent = "Força da senha: Forte";
  }

  marcarCriterio(criterioTamanho, texto.length >= 8);
  marcarCriterio(criterioMaiuscula, /[A-Z]/.test(texto));
  marcarCriterio(criterioMinuscula, /[a-z]/.test(texto));
  marcarCriterio(criterioNumero, /[0-9]/.test(texto));
  marcarCriterio(criterioEspecial, /[^A-Za-z0-9]/.test(texto));
}

// Monta a lista de erros (resumo) com elementos <li> criados pelo JS
function atualizarResumo() {
  listaErros.innerHTML = "";

  const erros = [];
  if (!nomeValido()) {
    erros.push("Nome: digite pelo menos 3 caracteres.");
  }
  if (!emailValido()) {
    erros.push("E-mail: use o formato nome@dominio.com.");
  }
  if (!senhaValida()) {
    erros.push("Senha: use 8 ou mais caracteres misturando maiúsculas, minúsculas, números e símbolos.");
  }
  if (!cursoValido()) {
    erros.push("Curso: selecione um curso.");
  }
  if (!termosValidos()) {
    erros.push("Termos: marque a caixa para aceitar.");
  }

  for (let i = 0; i < erros.length; i++) {
    const item = document.createElement("li");
    item.textContent = erros[i];
    listaErros.appendChild(item);
  }

  if (erros.length > 0) {
    resumoErros.classList.remove("oculto");
  } else {
    resumoErros.classList.add("oculto");
  }
}

// Habilita o botão só se tudo estiver válido
function atualizarBotao() {
  mensagemSucesso.classList.add("oculto");   // some com a mensagem de sucesso antiga

  const tudoOk = nomeValido() && emailValido() && senhaValida() && cursoValido() && termosValidos();
  btnEnviar.disabled = !tudoOk;

  if (tudoOk) {
    dicaBotao.textContent = "Tudo certo! Você já pode enviar o cadastro.";
  } else {
    dicaBotao.textContent = TEXTO_DICA;
  }

  atualizarResumo();
  return tudoOk;
}

// ----------------------------------------------------------
// 5. ETAPA 1 - Nome com contador (evento input)
// ----------------------------------------------------------
function atualizarContador() {
  const usados = nome.value.length;
  const restantes = LIMITE_NOME - usados;

  if (restantes === 0) {
    contadorNome.textContent = "Caracteres: " + usados + "/" + LIMITE_NOME + " (limite atingido)";
  } else {
    contadorNome.textContent = "Caracteres: " + usados + "/" + LIMITE_NOME + " (restam " + restantes + ")";
  }

  // feedback visual do limite
  if (restantes === 0) {
    contadorNome.classList.add("limite");
    contadorNome.classList.remove("aviso");
  } else if (restantes <= 10) {
    contadorNome.classList.add("aviso");
    contadorNome.classList.remove("limite");
  } else {
    contadorNome.classList.remove("aviso");
    contadorNome.classList.remove("limite");
  }
}

nome.addEventListener("input", () => {
  // não deixa passar de 50 caracteres
  if (nome.value.length > LIMITE_NOME) {
    nome.value = nome.value.slice(0, LIMITE_NOME);
  }
  atualizarContador();
  mostrarEstado(nome, mensagemNome, nomeValido(), "Nome válido.", "Digite pelo menos 3 caracteres.");
  atualizarBotao();
});

// ----------------------------------------------------------
// 6. ETAPA 2 - Estado -> Cidade (evento change)
// ----------------------------------------------------------
function preencherCidades(uf) {
  cidade.innerHTML = "";

  const opcaoPadrao = document.createElement("option");
  opcaoPadrao.value = "";

  if (uf === "") {
    opcaoPadrao.textContent = "Escolha um estado";
    cidade.appendChild(opcaoPadrao);
    cidade.disabled = true;
    return;
  }

  opcaoPadrao.textContent = "Selecione...";
  cidade.appendChild(opcaoPadrao);

  const lista = cidadesPorUF[uf];
  for (let i = 0; i < lista.length; i++) {
    const opcao = document.createElement("option");
    opcao.value = lista[i];
    opcao.textContent = lista[i];
    cidade.appendChild(opcao);
  }

  cidade.disabled = false;
}

estado.addEventListener("change", () => {
  preencherCidades(estado.value);
});

// ----------------------------------------------------------
// 7. ETAPA 3 - E-mail (eventos focus e blur)
// ----------------------------------------------------------
email.addEventListener("focus", () => {
  email.classList.add("focado");
});

email.addEventListener("blur", () => {
  email.classList.remove("focado");
  mostrarEstado(email, mensagemEmail, emailValido(), "E-mail válido.", "Corrija o e-mail. Use o formato nome@dominio.com");
  atualizarBotao();
});

// ----------------------------------------------------------
// 8. ETAPAS 4 e 5 - Senha, curso, termos e envio
// ----------------------------------------------------------
email.addEventListener("input", () => {
  atualizarBotao();
});

senha.addEventListener("input", () => {
  mostrarForca();
  mostrarEstado(senha, mensagemSenha, senhaValida(), "Senha aceita.",
    "Senha fraca. Misture letras, números e símbolos (mínimo 8).");
  atualizarBotao();
});

curso.addEventListener("change", () => {
  mostrarEstado(curso, mensagemCurso, cursoValido(), "Curso selecionado.", "Selecione um curso.");
  atualizarBotao();
});

termos.addEventListener("change", () => {
  mostrarEstado(termos, mensagemTermos, termosValidos(), "Termos aceitos.", "Marque a caixa para aceitar os termos.");
  atualizarBotao();
});

// Volta tudo ao estado inicial depois do envio
function limparFormulario() {
  formCadastro.reset();

  limparEstado(nome, mensagemNome);
  limparEstado(email, mensagemEmail);
  limparEstado(senha, mensagemSenha);
  limparEstado(curso, mensagemCurso);
  limparEstado(termos, mensagemTermos);

  preencherCidades("");
  atualizarContador();
  mostrarForca();
  resumoErros.classList.add("oculto");
  listaErros.innerHTML = "";
  btnEnviar.disabled = true;
  dicaBotao.textContent = TEXTO_DICA;
}

formCadastro.addEventListener("submit", (evento) => {
  evento.preventDefault();   // não recarrega a página

  if (!atualizarBotao()) {
    return;
  }

  const primeiroNome = nome.value.trim().split(" ")[0];
  limparFormulario();

  mensagemSucesso.textContent = "Cadastro enviado com sucesso! Obrigado, " + primeiroNome + ".";
  mensagemSucesso.classList.remove("oculto");
});
