João Vitor Mariotto Cerqueira Leite - RA:26006781 
Giovana Maria Usberti Magri - RA:26007694 
Leonardo Cupa Newman - RA:26005046

Turma: 0102-02-26-2s